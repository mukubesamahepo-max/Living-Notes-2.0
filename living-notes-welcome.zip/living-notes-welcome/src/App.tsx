import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, LockKeyhole, Mail, X } from 'lucide-react';

type Screen = 'welcome' | 'signin' | 'register';

function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [showPassword, setShowPassword] = useState(false);
  const [notice, setNotice] = useState('');

  const go = (next: Screen) => {
    setNotice('');
    setShowPassword(false);
    setScreen(next);
  };

  const submitPreview = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice('This is the design preview. Student accounts and sign-in will be connected when we build the authentication system.');
  };

  return (
    <main className="welcome-shell">
      <div className="artwork" aria-hidden="true" />
      <div className="shade" aria-hidden="true" />

      {screen === 'welcome' ? (
        <section className="welcome-content" aria-label="Living Notes welcome">
          <div className="brand-space" aria-hidden="true" />
          <div className="welcome-actions">
            <button className="button button-light" onClick={() => go('signin')}>Sign In</button>
            <button className="button button-outline" onClick={() => go('register')}>Create Account</button>
          </div>
        </section>
      ) : (
        <section className="auth-wrap" aria-label={screen === 'signin' ? 'Sign in' : 'Create account'}>
          <button className="back-button" onClick={() => go('welcome')} aria-label="Back to welcome"><ArrowLeft size={20} /></button>
          <div className="auth-card">
            <button className="close-button" onClick={() => go('welcome')} aria-label="Close"><X size={19} /></button>
            <div className="mini-brand"><span className="mini-book">▱</span><span>Living Notes</span></div>
            <p className="eyebrow">LEARN · PRACTICE · GROW</p>
            <h1>{screen === 'signin' ? 'Welcome back' : 'Create your account'}</h1>
            <p className="auth-subtitle">{screen === 'signin' ? 'Sign in to continue your learning journey.' : 'Start building better notes and bigger dreams.'}</p>
            <form onSubmit={submitPreview}>
              {screen === 'register' && <label>Full name<input required autoComplete="name" placeholder="Your full name" /></label>}
              <label>Email address<span className="input-wrap"><Mail size={18}/><input required type="email" autoComplete="email" placeholder="you@example.com" /></span></label>
              <label>Password<span className="input-wrap"><LockKeyhole size={18}/><input required minLength={6} type={showPassword ? 'text' : 'password'} autoComplete={screen === 'signin' ? 'current-password' : 'new-password'} placeholder="Enter your password"/><button className="reveal" type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></span></label>
              <button className="button button-primary" type="submit">{screen === 'signin' ? 'Sign In' : 'Create Account'}</button>
            </form>
            {notice && <p className="notice" role="status">{notice}</p>}
            <p className="switch-auth">{screen === 'signin' ? "Don't have an account?" : 'Already have an account?'} <button onClick={() => go(screen === 'signin' ? 'register' : 'signin')}>{screen === 'signin' ? 'Register' : 'Sign In'}</button></p>
          </div>
        </section>
      )}
      <span className="screen-reader-only">Living Notes. Learn, Practice, Grow. Better Notes. Bigger Dreams.</span>
    </main>
  );
}

export default App;
