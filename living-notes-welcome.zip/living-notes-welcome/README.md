# Living Notes — Welcome Screen Starter

This is the first coded milestone for the Living Notes responsive web app.

## Included
- The exact uploaded Living Notes welcome artwork at `public/images/living-notes-welcome.webp`.
- Responsive welcome screen with Sign In and Create Account actions.
- Sign-in and registration interface previews.
- Mobile-first styling with a desktop layout.

## Run locally
1. Install Node.js (18 or newer).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

## Important
Authentication is not connected yet. The sign-in and registration forms are UI previews only. Supabase authentication, database tables, access rules and admin permissions will be implemented in later milestones.

## Deploy
Push this folder to a GitHub repository and import the repository into Vercel. Use the default Vite build settings (`npm run build`, output folder `dist`).
